"""
Read file into texts and calls.
It's ok if you don't understand how to read files
"""
import csv
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

"""
TASK 2: Which telephone number spent the longest time on the phone
during the period? Don't forget that time spent answering a call is
also time spent on the phone.
Print a message:
"<telephone number> spent the longest time, <total time> seconds, on the phone during 
September 2016.".
"""

# Dictionary to store total time for each number
phone_time = {}

# Process all calls
for call in calls:
    calling_number = call[0]
    receiving_number = call[1]
    duration = int(call[3])
    
    # Add duration to calling number
    if calling_number in phone_time:
        phone_time[calling_number] += duration
    else:
        phone_time[calling_number] = duration
    
    # Add duration to receiving number
    if receiving_number in phone_time:
        phone_time[receiving_number] += duration
    else:
        phone_time[receiving_number] = duration

# Find the number with maximum time
max_time = 0
max_number = ""

for number, time in phone_time.items():
    if time > max_time:
        max_time = time
        max_number = number

print(f"{max_number} spent the longest time, {max_time} seconds, on the phone during September 2016.")

