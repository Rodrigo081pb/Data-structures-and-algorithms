# Time Complexity Analysis

## Task0

**Description**: The problem involves accessing the first record of texts and the last record of calls.

**Approach**: Direct indexing to access the first element of texts array and the last element of calls array.

**Complexity Analysis**:
- **Algorithm**: Direct array indexing operations - accessing first element with index 0 and last element with index -1.
- **Big O Notation**: O(1) - constant time
- **Justification**: Array indexing operations are constant time regardless of the size of the data. Both operations access specific positions without iteration.

## Task1

**Description**: Count the total number of unique telephone numbers across both texts and calls datasets.

**Approach**: Used a set data structure to store all unique phone numbers from both sending/receiving positions in texts and calls.

**Complexity Analysis**:
- **Algorithm**: Single pass through texts array (n elements) and calls array (m elements), adding each number to a set.
- **Big O Notation**: O(n + m) where n is the number of text records and m is the number of call records.
- **Justification**: Each record is processed once, and set insertion is O(1) average case. Total operations are proportional to the total number of records.

## Task2

**Description**: Find the telephone number that spent the longest time on the phone (including both making and receiving calls).

**Approach**: Used a dictionary to accumulate total call duration for each phone number, then found the maximum.

**Complexity Analysis**:
- **Algorithm**: Single pass through calls array (m elements) to build duration dictionary, then single pass through dictionary to find maximum.
- **Big O Notation**: O(m) where m is the number of call records.
- **Justification**: Each call record is processed once to accumulate durations (O(m)), and finding the maximum in the dictionary takes O(k) where k is the number of unique phone numbers. Since k ≤ 2m, the overall complexity is O(m).

## Task3

**Description**: Part A - Find all area codes and mobile prefixes called by Bangalore numbers. Part B - Calculate percentage of Bangalore-to-Bangalore calls.

**Approach**: 
- Part A: Filtered calls from Bangalore numbers, extracted codes from destination numbers, used set for uniqueness, then sorted.
- Part B: Counted total calls from Bangalore and calls from Bangalore to Bangalore.

**Complexity Analysis**:
- **Algorithm**: Single pass through calls array (m elements) for filtering and code extraction, plus sorting of unique codes.
- **Big O Notation**: O(m + k log k) where m is the number of call records and k is the number of unique codes.
- **Justification**: Processing calls is O(m), set operations are O(1) average case, and sorting k unique codes is O(k log k). Since k is typically much smaller than m, the complexity is dominated by O(m).

## Task4

**Description**: Identify potential telemarketers - numbers that make outgoing calls but never send/receive texts or receive incoming calls.

**Approach**: Built separate sets for outgoing callers, text senders, text receivers, and incoming call receivers. Found numbers in outgoing callers but not in any other category.

**Complexity Analysis**:
- **Algorithm**: Single pass through calls array (m elements) and texts array (n elements) to build sets, then set operations to find differences, followed by sorting.
- **Big O Notation**: O(n + m + t log t) where n is number of text records, m is number of call records, and t is the number of potential telemarketers.
- **Justification**: Building sets requires O(n + m) operations, set difference operations are O(k) where k is the number of unique outgoing callers, and sorting t results is O(t log t). The overall complexity is O(n + m + t log t).


